//! Device seam for the stage-0 packed one-hot trace commit.
//!
//! An installed [`TraceCommitDevice`] receives the flat trace selectors and
//! the digit-zero plane of the setup matrix and returns the committed rings
//! as canonical little-endian limbs. `commit_packed` keeps the CPU kernels
//! when no device is installed, when the device declines the shape, or when
//! the shape is not block-aligned (`segment_rings < positions_per_block`,
//! `K > D`).

use std::sync::{Arc, OnceLock};

use akita_algebra::CyclotomicRing;
use akita_error::AkitaError;
use akita_prover::compute::CommitInnerPlan;
use jolt_field::CanonicalEncoding;
use rayon::prelude::*;

use super::source::TracePackedOneHot;
use super::NO_SELECTED_ROW;
use crate::AkitaField;

/// Geometry of one trace commit, all counts in their natural units.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TraceCommitShape {
    pub one_hot_k: usize,
    pub ring_dimension: usize,
    /// Trace rows `T`.
    pub num_rows: usize,
    /// Semantic columns `C`; columns `C..column_capacity` are padding.
    pub num_columns: usize,
    pub column_capacity: usize,
    pub n_a: usize,
    pub positions_per_block: usize,
    pub num_digits_inner: usize,
    /// Rings per column segment: `num_rows * one_hot_k / ring_dimension`.
    pub segment_rings: usize,
    /// `segment_rings / positions_per_block`.
    pub blocks_per_column: usize,
    /// `column_capacity * blocks_per_column`.
    pub num_blocks: usize,
}

/// Inputs of one trace commit in device-friendly flat layouts.
pub struct TraceCommitJob<'a> {
    pub shape: TraceCommitShape,
    /// `num_rows * num_columns` row-major selected one-hot rows. Zero means
    /// "no committed entry" unless bit `column` of that row's mask is set.
    pub hot: &'a [u8],
    /// One committed-digit-zero mask per trace row.
    pub masks: &'a [u64],
    /// Digit-zero plane of the setup matrix as canonical LE u32 limbs:
    /// `((a * positions_per_block + q) * ring_dimension + i) * 4 + limb`.
    pub a_plane: &'a [u32],
}

pub trait TraceCommitDevice: Send + Sync {
    /// `None` declines the shape and the CPU kernels run instead.
    /// `Some(Ok(limbs))` carries `num_blocks * n_a * ring_dimension * 4`
    /// canonical LE u32 limbs indexed
    /// `((block * n_a + a) * ring_dimension + i) * 4 + limb` with
    /// `block = column * blocks_per_column + trace_block`; padding columns
    /// are zero.
    fn commit_accumulate(&self, job: &TraceCommitJob<'_>) -> Option<Result<Vec<u32>, AkitaError>>;
}

static DEVICE: OnceLock<Arc<dyn TraceCommitDevice>> = OnceLock::new();

/// Installs the process-wide trace commit device. Every later trace commit
/// offers its job to `device` first. Fails once a device is installed.
pub fn set_trace_commit_device(device: Arc<dyn TraceCommitDevice>) -> Result<(), AkitaError> {
    DEVICE
        .set(device)
        .map_err(|_| AkitaError::InvalidSetup("trace commit device already installed".to_string()))
}

pub(super) fn installed_trace_commit_device() -> Option<&'static dyn TraceCommitDevice> {
    DEVICE.get().map(Arc::as_ref)
}

const EXTRACT_ROWS_PER_TASK: usize = 1 << 10;

/// Offers the commit to `device`; `Ok(None)` means the CPU kernels must run.
/// Returned rows follow `CommitInnerWitness::from_rows` layout:
/// `rows[column * blocks_per_column + trace_block][a]`.
pub(super) fn commit_on_device<const D: usize>(
    device: &dyn TraceCommitDevice,
    source: &TracePackedOneHot,
    plan: CommitInnerPlan,
    a_rows: &[&[CyclotomicRing<AkitaField, D>]],
    segment_rings: usize,
    num_blocks: usize,
) -> Result<Option<Vec<Vec<CyclotomicRing<AkitaField, D>>>>, AkitaError> {
    if source.one_hot_k > D || segment_rings < plan.num_positions_per_block {
        return Ok(None);
    }
    let shape = TraceCommitShape {
        one_hot_k: source.one_hot_k,
        ring_dimension: D,
        num_rows: source.rows.num_rows(),
        num_columns: source.rows.num_columns(),
        column_capacity: source.column_capacity,
        n_a: plan.n_a,
        positions_per_block: plan.num_positions_per_block,
        num_digits_inner: plan.num_digits_inner,
        segment_rings,
        blocks_per_column: segment_rings / plan.num_positions_per_block,
        num_blocks,
    };
    let _span = tracing::info_span!(
        "trace_onehot_commit_device",
        one_hot_k = shape.one_hot_k,
        ring_dimension = D,
        num_rows = shape.num_rows,
        num_columns = shape.num_columns,
        column_capacity = shape.column_capacity,
        n_a = shape.n_a,
        positions_per_block = shape.positions_per_block,
        num_digits_inner = shape.num_digits_inner,
        blocks_per_column = shape.blocks_per_column,
        num_blocks = shape.num_blocks,
    )
    .entered();

    let extract_span = tracing::info_span!("trace_onehot_commit_device_extract").entered();
    let num_columns = shape.num_columns;
    let mut hot = vec![NO_SELECTED_ROW; shape.num_rows * num_columns];
    let mut masks = vec![0u64; shape.num_rows];
    hot.par_chunks_mut(EXTRACT_ROWS_PER_TASK * num_columns)
        .zip(masks.par_chunks_mut(EXTRACT_ROWS_PER_TASK))
        .enumerate()
        .try_for_each(|(task, (hot, masks))| {
            let row_start = task * EXTRACT_ROWS_PER_TASK;
            source.rows.fill_rows(row_start, hot);
            source
                .rows
                .fill_committed_digit_zero_masks(row_start, masks);
            match hot
                .iter()
                .find(|&&hot| hot != NO_SELECTED_ROW && usize::from(hot) >= source.one_hot_k)
            {
                Some(hot) => Err(AkitaError::InvalidInput(format!(
                    "trace one-hot row {hot} is outside K={}",
                    source.one_hot_k
                ))),
                None => Ok(()),
            }
        })?;
    let mut a_plane = vec![0u32; plan.n_a * plan.num_positions_per_block * D * 4];
    a_plane
        .par_chunks_exact_mut(D * 4)
        .enumerate()
        .for_each(|(index, limbs)| {
            let a = index / plan.num_positions_per_block;
            let position = index % plan.num_positions_per_block;
            let ring = &a_rows[a][position * plan.num_digits_inner];
            for (limbs, coefficient) in limbs.chunks_exact_mut(4).zip(ring.coefficients()) {
                let [lo, hi] = coefficient.to_limbs();
                limbs[0] = lo as u32;
                limbs[1] = (lo >> 32) as u32;
                limbs[2] = hi as u32;
                limbs[3] = (hi >> 32) as u32;
            }
        });
    drop(extract_span);

    let job = TraceCommitJob {
        shape,
        hot: &hot,
        masks: &masks,
        a_plane: &a_plane,
    };
    let Some(limbs) = device.commit_accumulate(&job) else {
        tracing::info!(?shape, "trace commit device declined the shape");
        return Ok(None);
    };
    let limbs = limbs?;
    let expected = num_blocks * plan.n_a * D * 4;
    if limbs.len() != expected {
        return Err(AkitaError::InvalidSize {
            expected,
            actual: limbs.len(),
        });
    }
    let _convert_span = tracing::info_span!("trace_onehot_commit_device_convert").entered();
    limbs
        .par_chunks_exact(plan.n_a * D * 4)
        .map(|block| {
            block
                .chunks_exact(D * 4)
                .map(|ring| {
                    let coefficients = ring
                        .chunks_exact(4)
                        .map(|limbs| {
                            let value = u128::from(limbs[0])
                                | u128::from(limbs[1]) << 32
                                | u128::from(limbs[2]) << 64
                                | u128::from(limbs[3]) << 96;
                            AkitaField::from_u128_checked(value).ok_or_else(|| {
                                AkitaError::InvalidInput(format!(
                                    "trace commit device returned non-canonical coefficient {value:#x}"
                                ))
                            })
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let coefficients: [AkitaField; D] = coefficients
                        .try_into()
                        .map_err(|_| AkitaError::InvalidSetup("ring dimension mismatch".to_string()))?;
                    Ok(CyclotomicRing::from_coefficients(coefficients))
                })
                .collect::<Result<Vec<_>, AkitaError>>()
        })
        .collect::<Result<Vec<_>, _>>()
        .map(Some)
}
