//! `std::time::Instant` has no clock on `wasm32-unknown-unknown` (`now()`
//! panics). The prover only reads it for diagnostics, so the wasm32 build
//! swaps in a zero-duration stand-in and keeps the timing code paths intact.

#[cfg(not(target_arch = "wasm32"))]
pub(crate) use std::time::Instant;

#[cfg(target_arch = "wasm32")]
#[derive(Clone, Copy, Debug)]
pub(crate) struct Instant;

#[cfg(target_arch = "wasm32")]
impl Instant {
    pub(crate) fn now() -> Self {
        Self
    }

    pub(crate) fn elapsed(&self) -> core::time::Duration {
        core::time::Duration::ZERO
    }
}
