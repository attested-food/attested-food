use super::device::{
    field_from_bytes, field_to_bytes, fields_from_bytes, fields_to_bytes, installed_device,
    parity_rounds, DeviceRounds, RelationRangeJob, RelationRangeShape, RoundInput, WeightsKind,
    FIELD_BYTES, MESSAGE_BYTES, TERMS,
};
use super::*;
use akita_serialization::{AkitaSerialize, Compress};

/// What `ingest_challenge` does with the CPU state after the device was
/// consulted.
pub(super) enum DeviceFold<E: Field> {
    /// The device owns the tables this round: the CPU fold is skipped.
    Skip,
    /// Fold on the CPU; with `Some`, compare the handed-back tables (already
    /// folded by this challenge) against the CPU state afterwards.
    Cpu(Option<(Vec<E>, Vec<E>)>),
}

/// One device round as the host consumes it.
pub(super) struct DeviceRound<E: Field> {
    pub(super) virt: NormRoundTerms<E>,
    pub(super) rel: [E; 3],
    pub(super) additional: UniPoly<E>,
}

const MAX_SEGMENTS: usize = 1 << 20;

impl<E: Field + Ring + Unreduced + AkitaSerialize> RelationRangeImageProver<E> {
    /// Offer the instance to the installed device (called from `new` before
    /// the two-round prefix is built).
    pub(super) fn try_open_device(&mut self) {
        let Some(device) = installed_device() else {
            return;
        };
        if E::zero().serialized_size(Compress::No) != FIELD_BYTES || self.num_vars < 2 {
            return;
        }
        let WitnessState::CompactPrefix(compact) = &self.witness_state else {
            return;
        };
        let (kind, domain_len) = match &self.relation_state {
            RelationRoundState::ReducedDense { weights } => {
                (WeightsKind::Dense, weights.evaluations().len())
            }
            RelationRoundState::QuotientFactored { weights, .. } => (
                WeightsKind::Factored,
                weights.common_alpha_factor().len() * weights.relation_lane_weights().len(),
            ),
        };
        let (lane_map, segments) = match kind {
            WeightsKind::Factored => match self.linear_terms.export_lane_segments(MAX_SEGMENTS) {
                Some(s) => s,
                None => {
                    tracing::info!("stage2_device_declined_linear_kind");
                    return;
                }
            },
            WeightsKind::Dense => (Vec::new(), Vec::new()),
        };
        let shape = RelationRangeShape {
            len: compact.len(),
            domain_len,
            coefficient_bits: self.coefficient_bits(),
            lane_bits: self.lane_bits,
            bit_width: compact.bit_width(),
            weights: kind,
            segments: segments.len(),
        };
        let rounds = device.rounds_for(&shape).min(self.num_vars - 1);
        if rounds == 0 {
            return;
        }
        let parity = parity_rounds() > 0;
        let started = Instant::now();
        let (weights, lane_weights) = match &self.relation_state {
            RelationRoundState::ReducedDense { weights: dense } => {
                let mut flat = dense.evaluations().to_vec();
                self.linear_terms.add_flat_into(&mut flat);
                if let Some(additional) = &self.additional_relation_terms {
                    additional.add_linear_into(&mut flat);
                }
                (fields_to_bytes(&flat), Vec::new())
            }
            RelationRoundState::QuotientFactored { weights, .. } => {
                (Vec::new(), fields_to_bytes(weights.relation_lane_weights()))
            }
        };
        let mut segment_bytes = Vec::with_capacity(segments.len() * 32);
        for (words, factor) in &segments {
            for w in words {
                segment_bytes.extend_from_slice(&w.to_le_bytes());
            }
            let mut f = [0u8; FIELD_BYTES];
            field_to_bytes(factor, &mut f);
            segment_bytes.extend_from_slice(&f);
        }
        let source_lanes = self.linear_terms.source_lanes();
        let weights_ms = started.elapsed().as_secs_f64() * 1e3;
        let job = RelationRangeJob {
            shape,
            digits: compact.encoded_bytes(),
            weights: &weights,
            lane_weights: &lane_weights,
            segments: &segment_bytes,
            lane_map: &lane_map,
            source_lanes: &source_lanes,
        };
        match device.open(&job, rounds) {
            Ok(session) => {
                tracing::info!(
                    rounds,
                    parity,
                    weights_ms,
                    kind = ?kind,
                    segments = segments.len(),
                    "stage2_device_plan"
                );
                // The flat table absorbed the additional linear weights; only the
                // binary part stays sparse. Parity keeps the CPU state intact.
                if kind == WeightsKind::Dense && !parity {
                    if let Some(additional) = &mut self.additional_relation_terms {
                        additional.drop_linear();
                    }
                }
                self.device = Some(DeviceRounds {
                    session: Some(session),
                    rounds,
                    prev: None,
                    parity,
                    kind,
                    witness_len: job.shape.len,
                    domain_len: job.shape.domain_len,
                });
            }
            Err(e) => self.device_error = Some(e),
        }
    }

    /// The device's terms for the current round (`None` when the device is
    /// not running this round). A device error is recorded and surfaces
    /// through `take_device_error`; the returned terms are then zero.
    pub(super) fn device_round(&mut self) -> Option<DeviceRound<E>> {
        let round = self.rounds_completed;
        let d = self.device.as_ref()?;
        if round >= d.rounds {
            return None;
        }
        let factored_phase = d.kind == WeightsKind::Factored && round <= self.coefficient_bits();
        let can_skip = self.can_skip_norm_linear_coeff();
        let (e_first, e_second) = self.split_eq.remaining_eq_tables();
        let e_first = fields_to_bytes(e_first);
        let e_second = fields_to_bytes(e_second);
        let (alpha, sources) = if factored_phase {
            match &self.relation_state {
                RelationRoundState::QuotientFactored { weights, .. } => (
                    fields_to_bytes(weights.common_alpha_factor()),
                    self.linear_terms.source_values_bytes(field_to_bytes),
                ),
                RelationRoundState::ReducedDense { .. } => (Vec::new(), Vec::new()),
            }
        } else {
            (Vec::new(), Vec::new())
        };
        // A dense flat table already carries the additional linear weights.
        let binary_only = d.kind == WeightsKind::Dense;
        let pairs = self
            .additional_relation_terms
            .as_ref()
            .map(|a| a.pairs_bytes(binary_only, field_to_bytes))
            .unwrap_or_default();
        let d = self.device.as_mut()?;
        let prev = d.prev.map(|r| {
            let mut bytes = [0u8; FIELD_BYTES];
            field_to_bytes(&r, &mut bytes);
            bytes
        });
        // The first error already fails the prove; a session that missed a
        // round is out of step with the host folds, so it is not driven further.
        let failed = self.device_error.is_some();
        let terms = (|| -> Result<[E; TERMS], AkitaError> {
            if failed {
                return Ok([E::zero(); TERMS]);
            }
            let session = d
                .session
                .as_mut()
                .ok_or_else(|| AkitaError::InvalidSetup("relation-range session closed".into()))?;
            let input = RoundInput {
                round,
                prev: prev.as_ref(),
                e_first: &e_first,
                e_second: &e_second,
                alpha: &alpha,
                sources: &sources,
                pairs: &pairs,
            };
            let mut out = [0u8; MESSAGE_BYTES];
            session.round(&input, &mut out)?;
            let mut terms = [E::zero(); TERMS];
            for (term, bytes) in terms.iter_mut().zip(out.chunks_exact(FIELD_BYTES)) {
                *term = field_from_bytes(bytes);
            }
            Ok(terms)
        })();
        let terms = match terms {
            Ok(terms) => terms,
            Err(e) => {
                self.device_error.get_or_insert(e);
                [E::zero(); TERMS]
            }
        };
        let virt = if can_skip {
            NormRoundTerms::SkipLinear([terms[0], terms[2]])
        } else {
            NormRoundTerms::Full([terms[0], terms[1], terms[2]])
        };
        let mut additional = terms[6..10].to_vec();
        trim_trailing_zeros(&mut additional);
        Some(DeviceRound {
            virt,
            rel: [terms[3], terms[4], terms[5]],
            additional: UniPoly::from_coeffs(additional),
        })
    }
}

impl<E: Field + Ring + Unreduced + Fold> RelationRangeImageProver<E> {
    /// The first device error, if any: trait methods cannot fail, so the seam
    /// records the error, keeps the rounds flowing and surfaces it here.
    pub fn take_device_error(&mut self) -> Result<(), AkitaError> {
        match self.device_error.take() {
            Some(e) => Err(e),
            None => Ok(()),
        }
    }

    /// Record challenge `r` for the device and fold the host-side pieces it
    /// does not own (Gruen tables, the factored alpha / linear sources in
    /// coefficient rounds, the live lane count, the sparse additional
    /// terms). On the device's last round take the tables back (folded by
    /// `r` here) and, unless parity keeps the CPU authoritative, resume the
    /// CPU prover from them.
    pub(super) fn device_ingest(&mut self, r: E) -> DeviceFold<E> {
        let Some(d) = self.device.as_ref() else {
            return DeviceFold::Cpu(None);
        };
        let round = self.rounds_completed;
        if round >= d.rounds {
            return DeviceFold::Cpu(None);
        }
        let (parity, kind, rounds, witness_len, domain_len) =
            (d.parity, d.kind, d.rounds, d.witness_len, d.domain_len);
        let last = round + 1 == rounds;
        if parity {
            if !last {
                if let Some(d) = self.device.as_mut() {
                    d.prev = Some(r);
                }
                return DeviceFold::Cpu(None);
            }
            return match self.device_take_tables(r, witness_len, domain_len, rounds) {
                Some(tables) => DeviceFold::Cpu(Some(tables)),
                None => DeviceFold::Cpu(None),
            };
        }
        self.split_eq.bind(r);
        let in_coefficient_round = self.in_coefficient_round();
        if let Some(additional) = &mut self.additional_relation_terms {
            additional.bind(r);
        }
        if kind == WeightsKind::Factored && in_coefficient_round {
            if let RelationRoundState::QuotientFactored { weights, .. } = &mut self.relation_state {
                fold_evals_in_place(weights.components_mut().0, r);
            }
            self.linear_terms.fold_coefficients(r);
        }
        if !in_coefficient_round {
            self.live_lane_count = self.live_lane_count.div_ceil(2);
        }
        if !last {
            if let Some(d) = self.device.as_mut() {
                d.prev = Some(r);
            }
            return DeviceFold::Skip;
        }
        let Some((witness, weights)) = self.device_take_tables(r, witness_len, domain_len, rounds)
        else {
            return DeviceFold::Skip;
        };
        self.witness_state = WitnessState::FoldedSuffix(witness);
        if !weights.is_empty() {
            let live_len = witness_len.div_ceil(1 << rounds);
            match DenseRelationWeights::new(weights, live_len) {
                Ok(dense) => {
                    self.relation_state = RelationRoundState::ReducedDense { weights: dense };
                }
                Err(e) => {
                    self.device_error.get_or_insert(e);
                    return DeviceFold::Skip;
                }
            }
            let coeff_count = 1usize << self.coefficient_bits().saturating_sub(rounds);
            self.linear_terms = PreparedProverLinearTerms::zero(self.live_lane_count, coeff_count);
        }
        DeviceFold::Skip
    }

    /// Take the device's tables after its last round and fold them by `r`;
    /// records a device error and returns `None` when they are malformed.
    fn device_take_tables(
        &mut self,
        r: E,
        witness_len: usize,
        domain_len: usize,
        rounds: usize,
    ) -> Option<(Vec<E>, Vec<E>)> {
        let d = self.device.take()?;
        let tables = d
            .session
            .ok_or_else(|| AkitaError::InvalidSetup("relation-range session closed".into()))
            .and_then(|session| session.tables())
            .and_then(|(w, p)| Ok((fields_from_bytes::<E>(&w)?, fields_from_bytes::<E>(&p)?)));
        let (mut witness, mut weights) = match tables {
            Ok(tables) => tables,
            Err(e) => {
                self.device_error.get_or_insert(e);
                return None;
            }
        };
        let expected_witness = witness_len.div_ceil(1 << (rounds - 1));
        let expected_weights = domain_len >> (rounds - 1);
        let lane_phase = rounds > self.coefficient_bits();
        let weights_ok = match d.kind {
            WeightsKind::Dense => weights.len() == expected_weights,
            WeightsKind::Factored => weights.len() == if lane_phase { expected_weights } else { 0 },
        };
        if witness.len() != expected_witness || !weights_ok {
            self.device_error.get_or_insert(AkitaError::InvalidSize {
                expected: expected_witness + expected_weights,
                actual: witness.len() + weights.len(),
            });
            return None;
        }
        fold_evals_in_place(&mut witness, r);
        if !weights.is_empty() {
            fold_evals_in_place(&mut weights, r);
        }
        Some((witness, weights))
    }
}

impl<E: Field + Ring + Unreduced> RelationRangeImageProver<E> {
    /// Parity mode: the handed-back tables must equal the CPU state.
    pub(super) fn check_device_tables(&mut self, witness: &[E], weights: &[E]) {
        let cpu_witness = match &self.witness_state {
            WitnessState::FoldedSuffix(w) => w.as_slice(),
            WitnessState::CompactPrefix(_) => &[],
        };
        let mut cpu_weights = match &self.relation_state {
            RelationRoundState::ReducedDense { weights } => weights.evaluations().to_vec(),
            RelationRoundState::QuotientFactored { weights, .. } => {
                if weights.common_alpha_factor().len() == 1 {
                    let alpha = weights.common_alpha_factor()[0];
                    weights
                        .relation_lane_weights()
                        .iter()
                        .map(|lane| alpha * *lane)
                        .collect()
                } else {
                    Vec::new()
                }
            }
        };
        if !weights.is_empty() {
            self.linear_terms.add_flat_into(&mut cpu_weights);
            if matches!(self.relation_state, RelationRoundState::ReducedDense { .. }) {
                if let Some(additional) = &self.additional_relation_terms {
                    additional.add_linear_into(&mut cpu_weights);
                }
            }
        }
        if cpu_witness != witness || (!weights.is_empty() && cpu_weights != weights) {
            self.device_error.get_or_insert(AkitaError::InvalidSetup(format!(
                "relation-range device handoff mismatch after round {} (witness {} vs {}, weights {} vs {})",
                self.rounds_completed,
                witness.len(),
                cpu_witness.len(),
                weights.len(),
                cpu_weights.len()
            )));
        } else {
            tracing::info!(round = self.rounds_completed, "stage2_device_tables_ok");
        }
    }

    /// Parity mode: the device's round polynomial must equal the CPU's.
    pub(super) fn check_device_poly(&mut self, cpu: &UniPoly<E>) {
        let Some(dev) = self.device_parity_poly.take() else {
            return;
        };
        if self.rounds_completed >= parity_rounds() {
            return;
        }
        if dev == *cpu {
            tracing::info!(round = self.rounds_completed, "stage2_device_parity_ok");
        } else {
            self.device_error.get_or_insert(AkitaError::InvalidSetup(format!(
                "relation-range device parity mismatch at round {} (num_vars {}, cpu degree {}, device degree {})",
                self.rounds_completed,
                self.num_vars,
                cpu.coeffs.len(),
                dev.coeffs.len()
            )));
        }
    }
}
