//! Optional device seam for the stage-2 relation-range sumcheck rounds.
//!
//! A [`RelationRangeDevice`] may take the first rounds of one instance. It
//! receives the compact digit witness once plus the relation weights either
//! as one flat table (`Dense`: dense weights + every linear term per padded
//! address) or factored (`Factored`: lane weights on the device, the common
//! alpha factor and the packing/sparse linear sources folded by the host and
//! passed per round with their lane segments). Per round it gets the
//! previous challenge, the prover's remaining Gruen eq tables and the sparse
//! additional pairs, and returns the ten round terms: norm `q0,q1,q2`
//! (eq-weighted), relation `c0,c1,c2`, additional cubic `a0..a3`. After its
//! last round it hands the folded witness (and the folded flat weights once
//! the lane phase started) back and the CPU prover finishes, so the
//! transcript, challenge derivation and proof layout are unchanged.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, OnceLock};

use akita_error::AkitaError;
use akita_serialization::{AkitaSerialize, Compress};
use jolt_field::solinas::parallel::*;
use jolt_field::{Field, Ring};

/// Canonical little-endian byte length of one field element on the wire.
pub const FIELD_BYTES: usize = 16;
/// Round messages: `virt[q0,q1,q2]`, `rel[c0,c1,c2]`, `add[a0,a1,a2,a3]`.
pub const TERMS: usize = 10;
pub const MESSAGE_BYTES: usize = TERMS * FIELD_BYTES;
/// One additional pair on the wire: `[m, 0, 0, 0]` u32 then `l0, l1, b0, b1`.
pub const PAIR_BYTES: usize = 5 * FIELD_BYTES;
/// One linear segment on the wire: `[source_lane, source_index, 0, 0]` u32
/// then `factor`; `lane_map[lane] = start << 8 | count` selects a lane's
/// segments.
pub const SEGMENT_BYTES: usize = 2 * FIELD_BYTES;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WeightsKind {
    /// `weights` holds `domain_len` flat entries, folded by the device.
    Dense,
    /// `alpha[coef] * lane_weights[lane] + segments`; the device folds the
    /// lane table into a flat table at the first lane round.
    Factored,
}

pub struct RelationRangeShape {
    /// Live witness length `live_lane_count * coeff_count`.
    pub len: usize,
    /// Padded relation domain (power of two, `>= len`).
    pub domain_len: usize,
    pub coefficient_bits: usize,
    pub lane_bits: usize,
    pub bit_width: u8,
    pub weights: WeightsKind,
    pub segments: usize,
}

pub struct RelationRangeJob<'a> {
    pub shape: RelationRangeShape,
    /// `len` digits, two's complement at `bit_width` bits each, LSB-first
    /// contiguous (`PackedSignedDigits`), flat index `lane * coeff_count +
    /// coefficient`.
    pub digits: &'a [u8],
    /// `Dense`: `domain_len` weights (16 B LE each); `Factored`: empty.
    pub weights: &'a [u8],
    /// `Factored`: `1 << lane_bits` lane weights; `Dense`: empty.
    pub lane_weights: &'a [u8],
    /// `Factored`: `shape.segments` linear segments (`SEGMENT_BYTES` each).
    pub segments: &'a [u8],
    /// `Factored`: one word per live lane, `start << 8 | count` into `segments`.
    pub lane_map: &'a [u32],
    /// `Factored`: lanes per linear source (source values are
    /// `lane_count * coeff_count`, lane-major).
    pub source_lanes: &'a [u32],
}

pub struct RoundInput<'a> {
    pub round: usize,
    /// Challenge that folds the tables before this round's evaluation
    /// (absent in round 0).
    pub prev: Option<&'a [u8; FIELD_BYTES]>,
    pub e_first: &'a [u8],
    pub e_second: &'a [u8],
    /// `Factored`, while `round <= coefficient_bits`: the common alpha
    /// factor folded so far (`coeff_count >> round` entries).
    pub alpha: &'a [u8],
    /// `Factored`, while `round <= coefficient_bits`: every linear source
    /// folded so far, concatenated.
    pub sources: &'a [u8],
    /// Additional pairs of this round (`PAIR_BYTES` each; binary weights
    /// pre-multiplied by the batching coefficient).
    pub pairs: &'a [u8],
}

pub trait RelationRangeSession: Send + Sync {
    fn round(
        &mut self,
        input: &RoundInput<'_>,
        out: &mut [u8; MESSAGE_BYTES],
    ) -> Result<(), AkitaError>;

    /// `(witness, weights)` as the last round evaluated them (folded by every
    /// earlier challenge): the witness has `ceil(len / 2^rounds_folded)`
    /// entries; the weights `domain_len >> rounds_folded` entries for `Dense`
    /// and for `Factored` once the lane phase started, otherwise empty.
    fn tables(self: Box<Self>) -> Result<(Vec<u8>, Vec<u8>), AkitaError>;
}

pub trait RelationRangeDevice: Send + Sync {
    /// Rounds the device would run on this shape; 0 declines (nothing is
    /// materialized for declined instances).
    fn rounds_for(&self, shape: &RelationRangeShape) -> usize;

    fn open(
        &self,
        job: &RelationRangeJob<'_>,
        rounds: usize,
    ) -> Result<Box<dyn RelationRangeSession>, AkitaError>;
}

static DEVICE: OnceLock<Arc<dyn RelationRangeDevice>> = OnceLock::new();
static PARITY_ROUNDS: AtomicUsize = AtomicUsize::new(0);

/// Install the process-wide device; fails if one is already installed.
pub fn set_relation_range_device(device: Arc<dyn RelationRangeDevice>) -> Result<(), AkitaError> {
    DEVICE
        .set(device)
        .map_err(|_| AkitaError::InvalidSetup("relation-range device already installed".into()))
}

/// Keep the CPU prover authoritative and check the device's first `rounds`
/// round polynomials and its handoff tables against it; a mismatch fails the
/// prove.
pub fn set_relation_range_parity_rounds(rounds: usize) {
    PARITY_ROUNDS.store(rounds, Ordering::SeqCst);
}

pub(super) fn installed_device() -> Option<&'static Arc<dyn RelationRangeDevice>> {
    DEVICE.get()
}

pub(super) fn parity_rounds() -> usize {
    PARITY_ROUNDS.load(Ordering::SeqCst)
}

pub(super) fn field_to_bytes<E: Field + AkitaSerialize>(value: &E, out: &mut [u8]) {
    let mut cursor = std::io::Cursor::new(out);
    value
        .serialize_with_mode(&mut cursor, Compress::No)
        .expect("16-byte field element serializes into a 16-byte slot");
}

pub(super) fn fields_to_bytes<E: Field + AkitaSerialize>(values: &[E]) -> Vec<u8> {
    let mut out = vec![0u8; values.len() * FIELD_BYTES];
    cfg_chunks_mut!(out, FIELD_BYTES * 4096)
        .zip(cfg_chunks!(values, 4096))
        .for_each(|(chunk, values)| {
            for (value, slot) in values.iter().zip(chunk.chunks_exact_mut(FIELD_BYTES)) {
                field_to_bytes(value, slot);
            }
        });
    out
}

pub(super) fn field_from_bytes<E: Ring>(bytes: &[u8]) -> E {
    let mut word = [0u8; FIELD_BYTES];
    word.copy_from_slice(bytes);
    E::from_u128(u128::from_le_bytes(word))
}

pub(super) fn fields_from_bytes<E: Ring>(bytes: &[u8]) -> Result<Vec<E>, AkitaError> {
    if !bytes.len().is_multiple_of(FIELD_BYTES) {
        return Err(AkitaError::InvalidSize {
            expected: bytes.len().div_ceil(FIELD_BYTES) * FIELD_BYTES,
            actual: bytes.len(),
        });
    }
    Ok(bytes
        .chunks_exact(FIELD_BYTES)
        .map(field_from_bytes)
        .collect())
}

/// Device state of one prover while its rounds run on the device.
pub(super) struct DeviceRounds<E: Field> {
    pub(super) session: Option<Box<dyn RelationRangeSession>>,
    pub(super) rounds: usize,
    pub(super) prev: Option<E>,
    /// CPU state stays authoritative; device polynomials and tables are compared.
    pub(super) parity: bool,
    pub(super) kind: WeightsKind,
    pub(super) witness_len: usize,
    pub(super) domain_len: usize,
}
