//! Optional device seam for the basis-8 direct-leaf digit-range sumcheck.
//!
//! A [`DigitRangeDevice`] may take the first rounds of one instance: it
//! receives the packed witness once, then per round the previous challenge
//! and the prover's own remaining Gruen eq tables, and returns the round's
//! `q` coefficients. After its last round the device hands back the folded
//! table and [`LowBasisRangeCheckProver`] finishes on the CPU, so the
//! transcript, challenge derivation and proof layout are unchanged.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, OnceLock};

use akita_algebra::split_eq::GruenSplitEq;
use akita_error::AkitaError;
use akita_serialization::{AkitaSerialize, Compress};
use akita_sumcheck::{fold_evals_in_place, EqFactoredSumcheckInstanceProver, EqFactoredUniPoly};
use akita_types::DigitRangePlan;
use jolt_field::{Field, Fold, Ring, Unreduced};

use super::direct_range_leaf::LowBasisRangeCheckProver;
use crate::backend::packed_digits::PackedSignedDigits;

/// Canonical little-endian byte length of one field element on the wire.
pub const FIELD_BYTES: usize = 16;
/// Round messages carry the five coefficients of `q(X)` (degree 4).
pub const Q_COEFFS: usize = 5;
pub const MESSAGE_BYTES: usize = Q_COEFFS * FIELD_BYTES;

/// One basis-8 direct-leaf instance as bytes: `len` digits in two's
/// complement at `bit_width` bits each, LSB-first contiguous, flat index
/// `x << ring_bits | y`.
pub struct DigitRangeJob<'a> {
    pub digits: &'a [u8],
    pub bit_width: u8,
    pub len: usize,
    pub ring_bits: usize,
    pub num_vars: usize,
}

pub trait DigitRangeSession: Send + Sync {
    /// Fold the table by `prev` (absent in round 0), then write round
    /// `round`'s `q` coefficients (canonical 16 B LE each) into `out`.
    /// `e_first`/`e_second` are this round's remaining Gruen tables.
    fn round(
        &mut self,
        round: usize,
        prev: Option<&[u8; FIELD_BYTES]>,
        e_first: &[u8],
        e_second: &[u8],
        out: &mut [u8; MESSAGE_BYTES],
    ) -> Result<(), AkitaError>;

    /// The table the last round evaluated (folded by every earlier
    /// challenge), 16 B LE per entry.
    fn table(self: Box<Self>) -> Result<Vec<u8>, AkitaError>;
}

pub trait DigitRangeDevice: Send + Sync {
    /// `None` declines the instance. `Some(Ok((session, rounds)))` runs the
    /// first `rounds` rounds on the device; the seam clamps `rounds` to
    /// `1..=ring_bits` so the handoff table is still in the low-variable phase.
    fn open(
        &self,
        job: &DigitRangeJob<'_>,
    ) -> Option<Result<(Box<dyn DigitRangeSession>, usize), AkitaError>>;
}

static DEVICE: OnceLock<Arc<dyn DigitRangeDevice>> = OnceLock::new();
static PARITY_ROUNDS: AtomicUsize = AtomicUsize::new(0);

/// Install the process-wide device; fails if one is already installed.
pub fn set_digit_range_device(device: Arc<dyn DigitRangeDevice>) -> Result<(), AkitaError> {
    DEVICE
        .set(device)
        .map_err(|_| AkitaError::InvalidSetup("digit-range device already installed".into()))
}

/// Check the device's first `rounds` messages against the CPU prover on the
/// same state; a mismatch fails the prove. Costs a full CPU instance.
pub fn set_digit_range_parity_rounds(rounds: usize) {
    PARITY_ROUNDS.store(rounds, Ordering::SeqCst);
}

fn field_to_bytes<E: Field + AkitaSerialize>(value: &E, out: &mut [u8]) {
    let mut cursor = std::io::Cursor::new(out);
    value
        .serialize_with_mode(&mut cursor, Compress::No)
        .expect("16-byte field element serializes into a 16-byte slot");
}

fn fields_to_bytes<E: Field + AkitaSerialize>(values: &[E]) -> Vec<u8> {
    let mut out = vec![0u8; values.len() * FIELD_BYTES];
    for (value, slot) in values.iter().zip(out.chunks_exact_mut(FIELD_BYTES)) {
        field_to_bytes(value, slot);
    }
    out
}

fn field_from_bytes<E: Ring>(bytes: &[u8]) -> E {
    let mut word = [0u8; FIELD_BYTES];
    word.copy_from_slice(bytes);
    E::from_u128(u128::from_le_bytes(word))
}

struct DeviceRounds<E: Field> {
    session: Option<Box<dyn DigitRangeSession>>,
    split_eq: GruenSplitEq<E>,
    rounds: usize,
    prev: Option<E>,
    /// CPU prover fed the same challenges, present only while parity
    /// checking is on.
    shadow: Option<LowBasisRangeCheckProver<E>>,
}

enum Phase<E: Field> {
    Device(DeviceRounds<E>),
    Cpu(LowBasisRangeCheckProver<E>),
    /// Transient state while the table moves from the device to the CPU.
    Handoff,
}

/// Direct-leaf prover that runs its first rounds on the installed device
/// when one accepts the instance, and on the CPU otherwise.
pub(super) struct DeviceLeaf<E: Field> {
    phase: Phase<E>,
    basis: usize,
    live_x_cols: usize,
    col_bits: usize,
    ring_bits: usize,
    error: Option<AkitaError>,
}

impl<E: Field + Ring + Unreduced + Fold + AkitaSerialize> DeviceLeaf<E> {
    pub(super) fn new(
        digit_witness: PackedSignedDigits,
        tau0: &[E],
        plan: DigitRangePlan,
        live_x_cols: usize,
        col_bits: usize,
        ring_bits: usize,
    ) -> Result<Self, AkitaError> {
        let cpu = LowBasisRangeCheckProver::new(
            digit_witness.clone(),
            tau0,
            plan,
            live_x_cols,
            col_bits,
            ring_bits,
        )?;
        let basis = plan.basis();
        let mut leaf = Self {
            phase: Phase::Cpu(cpu),
            basis,
            live_x_cols,
            col_bits,
            ring_bits,
            error: None,
        };
        let Some(device) = DEVICE.get() else {
            return Ok(leaf);
        };
        let field_ok = E::zero().serialized_size(Compress::No) == FIELD_BYTES;
        if basis != 8 || !field_ok || ring_bits == 0 {
            return Ok(leaf);
        }
        let job = DigitRangeJob {
            digits: digit_witness.encoded_bytes(),
            bit_width: digit_witness.bit_width(),
            len: digit_witness.len(),
            ring_bits,
            num_vars: tau0.len(),
        };
        let Some(opened) = device.open(&job) else {
            return Ok(leaf);
        };
        let (session, rounds) = opened?;
        let rounds = rounds.clamp(1, ring_bits);
        let shadow = (PARITY_ROUNDS.load(Ordering::SeqCst) > 0)
            .then(|| {
                LowBasisRangeCheckProver::new(
                    digit_witness,
                    tau0,
                    plan,
                    live_x_cols,
                    col_bits,
                    ring_bits,
                )
            })
            .transpose()?;
        leaf.phase = Phase::Device(DeviceRounds {
            session: Some(session),
            split_eq: GruenSplitEq::new(tau0)?,
            rounds,
            prev: None,
            shadow,
        });
        Ok(leaf)
    }

    /// Rounds the device ran (0 on the CPU path).
    pub(super) fn device_rounds(&self) -> usize {
        match &self.phase {
            Phase::Device(d) => d.rounds,
            Phase::Cpu(_) | Phase::Handoff => 0,
        }
    }

    /// The first device error, if any. Trait methods cannot fail, so the
    /// seam records the error, returns zero messages and surfaces it here.
    pub(super) fn take_error(&mut self) -> Result<(), AkitaError> {
        match self.error.take() {
            Some(e) => Err(e),
            None => Ok(()),
        }
    }

    pub(super) fn final_range_image_eval(&self) -> E {
        match &self.phase {
            Phase::Cpu(cpu) => cpu.final_range_image_eval(),
            Phase::Device(_) | Phase::Handoff => {
                panic!("digit-range device never handed the table back")
            }
        }
    }

    fn zero_message(&self) -> EqFactoredUniPoly<E> {
        EqFactoredUniPoly::from_q_coeffs(vec![E::zero(); Q_COEFFS])
    }

    fn device_round(&mut self, round: usize) -> Result<EqFactoredUniPoly<E>, AkitaError> {
        let Phase::Device(d) = &mut self.phase else {
            unreachable!("device_round outside the device phase")
        };
        let session = d
            .session
            .as_mut()
            .ok_or_else(|| AkitaError::InvalidSetup("digit-range session closed".into()))?;
        let prev = d.prev.map(|r| {
            let mut bytes = [0u8; FIELD_BYTES];
            field_to_bytes(&r, &mut bytes);
            bytes
        });
        let (e_first, e_second) = d.split_eq.remaining_eq_tables();
        let e_first = fields_to_bytes(e_first);
        let e_second = fields_to_bytes(e_second);
        let mut out = [0u8; MESSAGE_BYTES];
        session.round(round, prev.as_ref(), &e_first, &e_second, &mut out)?;
        let q_coeffs: Vec<E> = out
            .chunks_exact(FIELD_BYTES)
            .map(field_from_bytes)
            .collect();
        let poly = EqFactoredUniPoly::from_q_coeffs(q_coeffs);
        if let Some(shadow) = d.shadow.as_mut() {
            if round < PARITY_ROUNDS.load(Ordering::SeqCst) {
                let expected = shadow.compute_round_eq_factored(round);
                if expected != poly {
                    return Err(AkitaError::InvalidSetup(format!(
                        "digit-range device parity mismatch at round {round} (num_vars {}, live_x_cols {})",
                        d.split_eq.remaining_eq_tables().0.len(), self.live_x_cols
                    )));
                }
                tracing::info!(round, "digit_range_device_parity_ok");
            }
        }
        Ok(poly)
    }

    fn device_ingest(&mut self, round: usize, r: E) -> Result<(), AkitaError> {
        let Phase::Device(d) = &mut self.phase else {
            unreachable!("device_ingest outside the device phase")
        };
        d.split_eq.bind(r);
        d.prev = Some(r);
        if let Some(shadow) = d.shadow.as_mut() {
            shadow.ingest_challenge(round, r);
        }
        if round + 1 < d.rounds {
            return Ok(());
        }
        let session = d
            .session
            .take()
            .ok_or_else(|| AkitaError::InvalidSetup("digit-range session closed".into()))?;
        let bytes = session.table()?;
        let expected_len = (self.live_x_cols << self.ring_bits) >> round;
        if bytes.len() != expected_len * FIELD_BYTES {
            return Err(AkitaError::InvalidSize {
                expected: expected_len * FIELD_BYTES,
                actual: bytes.len(),
            });
        }
        let mut table: Vec<E> = bytes
            .chunks_exact(FIELD_BYTES)
            .map(field_from_bytes)
            .collect();
        fold_evals_in_place(&mut table, r);
        let Phase::Device(d) = std::mem::replace(&mut self.phase, Phase::Handoff) else {
            unreachable!()
        };
        self.phase = Phase::Cpu(LowBasisRangeCheckProver::from_materialized(
            table,
            d.split_eq,
            self.basis,
            self.live_x_cols,
            self.col_bits,
            self.ring_bits,
            d.rounds,
        ));
        Ok(())
    }
}

impl<E: Field + Ring + Unreduced + Fold + AkitaSerialize> EqFactoredSumcheckInstanceProver<E>
    for DeviceLeaf<E>
{
    fn num_rounds(&self) -> usize {
        self.col_bits + self.ring_bits
    }

    fn degree_bound(&self) -> usize {
        self.basis / 2
    }

    fn input_claim(&self) -> E {
        E::zero()
    }

    fn current_tau(&self) -> E {
        match &self.phase {
            Phase::Device(d) => d.split_eq.current_tau(),
            Phase::Cpu(cpu) => cpu.current_tau(),
            Phase::Handoff => unreachable!(),
        }
    }

    fn compute_round_eq_factored(&mut self, round: usize) -> EqFactoredUniPoly<E> {
        match &mut self.phase {
            Phase::Cpu(cpu) => cpu.compute_round_eq_factored(round),
            Phase::Handoff => unreachable!(),
            Phase::Device(_) => {
                if self.error.is_some() {
                    return self.zero_message();
                }
                match self.device_round(round) {
                    Ok(poly) => poly,
                    Err(e) => {
                        self.error = Some(e);
                        self.zero_message()
                    }
                }
            }
        }
    }

    fn ingest_challenge(&mut self, round: usize, r_round: E) {
        match &mut self.phase {
            Phase::Cpu(cpu) => cpu.ingest_challenge(round, r_round),
            Phase::Handoff => unreachable!(),
            Phase::Device(_) => {
                if let Err(e) = self.device_ingest(round, r_round) {
                    self.error.get_or_insert(e);
                }
            }
        }
    }
}
